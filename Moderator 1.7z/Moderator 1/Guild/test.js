const { MessageEmbed } = require('discord.js');

module.exports.config = { 
    name: 'test',
    aliases: ['testing','raviwen']
}

module.exports.raviwen = async(client, message, args, config) => {

};